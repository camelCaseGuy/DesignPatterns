package refactoring;

public class Main {
    public static void main(String[] args) {
        Customer greg = new Customer("Greg");
        // Movie titanicMovie = new RegularMovie("Titanic");
        Movie careBearsMovie = new ChildrensMovie("Care Bears");
        Movie oppenheimerMovie = new NewReleaseMovie("Oppenheimer");
        Movie someMovie = new Movie("A Movie");
        // Rental titanicRental = new Rental(newRegularMoviePriceCalculationStrategy, 3);
        Rental careBearsRental = new Rental(careBearsMovie, 1);
        Rental oppenheimerRental = new Rental(oppenheimerMovie, 5);
        Rental someRental = new Rental(someMovie, 4);
        // greg.addRental(titanicRental);
        greg.addRental(careBearsRental);
        greg.addRental(oppenheimerRental);
        greg.addRental(someRental);
        greg.calculateAmountAndPoints();
        greg.printStatement(greg);
      }
}
