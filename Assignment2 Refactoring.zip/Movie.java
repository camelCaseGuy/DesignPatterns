package refactoring;

public class Movie {
  
  private String _title;
  
  public Movie(String title) {
      _title = title;
  }
  
  public String getTitle() {
      return _title;
  }

  public double getAmount(int _daysRented) {
    return _daysRented * 1;
  }

  public int getBonusPoints(int _daysRented) {
    return _daysRented * 1;
  }

}
