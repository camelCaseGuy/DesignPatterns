package refactoring;

public class RegularMovie extends Movie {

  public RegularMovie(String title) {
    super(title);
  }

  public double getAmount(int _daysRented) {
    double thisAmount = 2;
    if (_daysRented > 2) {
      thisAmount += (_daysRented - 2) * 1.5;
    }
    return thisAmount;
  }

}
