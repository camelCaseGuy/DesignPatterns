package refactoring;

public class Rental {
  private Movie _movie;
  private int   _daysRented;
  private int   _frequentRentalPoints;
  // BASE_PRICE, BASE_POINTS
  public Rental(Movie movie, int daysRented) {
      _movie      = movie;
      _daysRented = daysRented;
  }
  
  public int getDaysRented() {
      return _daysRented;
  }
  
  public Movie getMovie() {
      return _movie;
  }
  
  public double getAmount() {
    return _movie.getAmount(_daysRented);
    
  }

  public int getRentalPoints() {
    _frequentRentalPoints++;
    int getBonusPoints = _movie.getBonusPoints(_daysRented);
    _frequentRentalPoints += getBonusPoints;
    return _frequentRentalPoints;
  }
}